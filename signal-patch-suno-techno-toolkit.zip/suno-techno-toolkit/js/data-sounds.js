/* ==========================================================================
   SOUND LIBRARY DATA
   Every entry: { id, name, category, subtype?, keyword, desc, role, engine, params }
   - keyword : the exact phrase to drop into a Suno Style-of-Music field
   - desc    : what the sound physically is
   - role    : why a techno producer reaches for it / what it does in a track
   - engine  : which synth engine in audio-engine.js renders the preview
   - params  : engine-specific synthesis parameters
   NOTE: previews are original Web Audio synthesis built to *approximate* the
   character of each sound — they are reference sketches, not the actual
   Suno output, and not samples of copyrighted drum machines or records.
   ========================================================================== */

window.SOUND_LIBRARY = [

// ---------------------------------------------------------------------- KICK
{
  id: 'kick-peak-time', name: 'Peak-Time Kick', category: 'kick',
  keyword: 'punchy peak-time techno kick',
  desc: 'A tight kick with a fast pitch snap from click to thud and a short tail.',
  role: 'The backbone of a peak-time set — short enough to stay out of the way at loud PA volumes, letting a separate sub layer carry the low-end weight.',
  engine: 'kick', params: { startFreq:180, endFreq:48, pitchDecay:0.045, ampDecay:0.32, drive:0.25, click:0.6, sub:0.5 }
},
{
  id: 'kick-rolling-minimal', name: 'Rolling Minimal Kick', category: 'kick',
  keyword: 'rolling minimal techno kick, soft transient',
  desc: 'A rounder, softer-attack kick with a longer pitch glide and gentle low end.',
  role: 'Built to loop for minutes without fatigue — minimal techno leans on a kick you can groove to for eight bars straight without it fighting the percussion.',
  engine: 'kick', params: { startFreq:140, endFreq:50, pitchDecay:0.06, ampDecay:0.28, drive:0.1, click:0.3, sub:0.4 }
},
{
  id: 'kick-industrial-distorted', name: 'Distorted Industrial Kick', category: 'kick',
  keyword: 'distorted industrial techno kick, saturated',
  desc: 'A heavily saturated kick where the drive stage adds grit and upper harmonics.',
  role: 'Gives industrial techno its mechanical, metallic low end — the distortion pushes the kick into the mids so it reads as aggressive even on small speakers.',
  engine: 'kick', params: { startFreq:160, endFreq:45, pitchDecay:0.05, ampDecay:0.4, drive:0.7, click:0.4, sub:0.3 }
},
{
  id: 'kick-deep-dub', name: 'Deep Dub Kick', category: 'kick',
  keyword: 'deep dub techno kick, soft attack, long tail',
  desc: 'A slow, round kick with almost no click and a long, warm decay.', 
  role: 'Dub techno hides the kick inside the chords instead of in front of them — a soft attack lets it sit underneath reverb-drenched stabs without clashing.',
  engine: 'kick', params: { startFreq:110, endFreq:42, pitchDecay:0.09, ampDecay:0.5, drive:0.05, click:0.15, sub:0.7 }
},
{
  id: 'kick-hard-techno', name: 'Hard Techno Kick', category: 'kick',
  keyword: 'hard techno kick, distorted, aggressive transient',
  desc: 'A fast, splashy click into a heavily driven, almost square-wave body.',
  role: 'Hard techno and schranz push the kick until it becomes a rhythmic distortion instrument in its own right — it is loud enough to define the track\u2019s whole identity.',
  engine: 'kick', params: { startFreq:200, endFreq:55, pitchDecay:0.035, ampDecay:0.3, drive:0.85, click:0.7, sub:0.35 }
},
{
  id: 'kick-acid-ready', name: 'Acid-Ready Kick', category: 'kick',
  keyword: 'tight acid techno kick, short decay',
  desc: 'A short, dry kick with a clear click, cut deliberately tight in the tail.',
  role: 'Leaves a pocket of silence for a resonant 303 bassline to squelch into — acid techno needs the kick out of the bass\u2019s frequency space fast.',
  engine: 'kick', params: { startFreq:170, endFreq:50, pitchDecay:0.04, ampDecay:0.25, drive:0.3, click:0.55, sub:0.4 }
},
{
  id: 'kick-sub-warehouse', name: 'Sub-Heavy Warehouse Kick', category: 'kick',
  keyword: 'sub-heavy warehouse techno kick, deep low end',
  desc: 'A long, weighty kick where most of the energy sits below 60Hz.',
  role: 'Written for a big rig, not headphones — this is the kick that moves air in a warehouse and gives a track physical weight on a proper system.',
  engine: 'kick', params: { startFreq:130, endFreq:40, pitchDecay:0.07, ampDecay:0.55, drive:0.15, click:0.2, sub:0.85 }
},
{
  id: 'kick-lofi-analog', name: 'Lo-fi Analog Kick', category: 'kick',
  keyword: 'lo-fi analog drum machine kick, dusty',
  desc: 'A dulled, slightly boxy kick as if run through worn analog circuitry.',
  role: 'Adds character and imperfection — useful when a track is too clean and needs the warmth and grit of vintage drum-machine hardware.',
  engine: 'kick', params: { startFreq:150, endFreq:48, pitchDecay:0.05, ampDecay:0.3, drive:0.2, click:0.35, sub:0.3, tone:3600 }
},

// ----------------------------------------------------------------- HAT/CYMBAL
{
  id: 'hat-closed-tight', name: 'Closed Hat (Tight)', category: 'hat',
  keyword: 'tight closed hi-hat, 16th note',
  desc: 'A short, high, filtered noise tick with almost no ring.',
  role: 'Drives the groove forward on the 16ths without adding clutter — the shortness is what keeps a fast pattern feeling crisp instead of washy.',
  engine: 'hat', params: { decay:0.05, filterFreq:8000, filterQ:1.2, metallic:false, noiseType:'white' }
},
{
  id: 'hat-open-driving', name: 'Open Hat (Driving)', category: 'hat',
  keyword: 'driving open hi-hat, offbeat',
  desc: 'A longer, airier noise burst that rings out before the next kick cuts it off.',
  role: 'The classic offbeat \u201cchick\u201d that makes a four-on-the-floor track swing forward — it defines the pulse as much as the kick does.',
  engine: 'hat', params: { decay:0.28, filterFreq:7000, filterQ:0.9, metallic:false, noiseType:'white' }
},
{
  id: 'hat-metallic', name: 'Metallic Hat', category: 'hat',
  keyword: 'metallic techno hi-hat, bell-like',
  desc: 'A noise burst layered with a few inharmonic sine partials for a bell-like ring.',
  role: 'Reads as more \u201ctuned\u201d and deliberate than a plain noise hat — useful in melodic and hypnotic techno where every element needs a pitch identity.',
  engine: 'hat', params: { decay:0.22, filterFreq:9000, filterQ:2, metallic:true, noiseType:'white' }
},
{
  id: 'hat-shaker', name: 'Analog Shaker', category: 'hat',
  keyword: 'analog shaker loop, steady 16ths',
  desc: 'A soft, mid-filtered noise texture with a rounder envelope than a hat.',
  role: 'Fills the gaps between kick and hat with constant, low-key motion — a staple of tribal and hypnotic techno grooves that need to feel alive without new events.',
  engine: 'hat', params: { decay:0.09, filterFreq:4500, filterQ:0.6, metallic:false, noiseType:'pink' }
},
{
  id: 'hat-ride-hypnotic', name: 'Ride Cymbal (Hypnotic)', category: 'hat',
  keyword: 'hypnotic ride cymbal, sustained wash',
  desc: 'A sustained, shimmering noise wash with a slow decay and metallic overtones.',
  role: 'Sits underneath everything as a constant shimmer — hypnotic and Berlin-style techno often use it instead of a hat to soften the groove\u2019s edges.',
  engine: 'hat', params: { decay:0.6, filterFreq:6500, filterQ:1.5, metallic:true, noiseType:'white' }
},
{
  id: 'hat-crash-riser', name: 'Crash Riser Cymbal', category: 'hat',
  keyword: 'crash cymbal riser, bright wash',
  desc: 'A long, bright, slowly-decaying cymbal wash used as a one-off accent.',
  role: 'Marks a section change — a single crash at the top of a drop or breakdown tells the listener\u2019s ear \u201csomething just happened\u201d without needing a full fill.',
  engine: 'hat', params: { decay:1.6, filterFreq:8000, filterQ:0.8, metallic:true, noiseType:'white' }
},
{
  id: 'hat-tape-saturated', name: 'Tape-Saturated Hat', category: 'hat',
  keyword: 'tape-saturated hi-hat, warm and dull',
  desc: 'A closed hat with its top end rolled off, as if recorded through tape.',
  role: 'Softens a pattern that feels too digital or brittle — common in dub and deep techno where warmth matters more than sparkle.',
  engine: 'hat', params: { decay:0.07, filterFreq:4200, filterQ:1, metallic:false, noiseType:'pink' }
},
{
  id: 'hat-industrial-metal', name: 'Industrial Metal Hat', category: 'hat',
  keyword: 'industrial metal hi-hat, harsh and clanky',
  desc: 'A harsh, high-Q metallic burst that sounds closer to struck metal than a cymbal.',
  role: 'Reinforces an industrial track\u2019s mechanical, factory-floor identity — it is meant to sound like hardware, not a drum kit.',
  engine: 'hat', params: { decay:0.15, filterFreq:10500, filterQ:4, metallic:true, noiseType:'white' }
},

// --------------------------------------------------------------- PERCUSSION
{
  id: 'perc-analog-clap', name: 'Analog Clap', category: 'perc',
  keyword: 'classic analog clap, snappy',
  desc: 'A tight cluster of quick noise bursts through a mid-range bandpass filter.',
  role: 'The standard backbeat hit on beats 2 and 4 — it adds a human-feeling accent against the mechanical regularity of the kick.',
  engine: 'perc', params: { type:'clap', filterFreq:1500, decay:0.18, bursts:4 }
},
{
  id: 'perc-rave-clap-layered', name: 'Layered Rave Clap', category: 'perc',
  keyword: 'layered rave clap, wide and thick',
  desc: 'A wider, denser clap built from more overlapping bursts for extra body.',
  role: 'Gives peak-time and hard techno a bigger backbeat that still reads clearly over a loud, distorted kick.',
  engine: 'perc', params: { type:'clap', filterFreq:1800, decay:0.24, bursts:6 }
},
{
  id: 'perc-rimshot', name: 'Rimshot', category: 'perc',
  keyword: 'tight rimshot percussion',
  desc: 'A very short, high-pitched click with a touch of tonal snap.',
  role: 'Adds a light, dry accent between kicks without competing for low-mid space — useful for driving a groove without a full clap.',
  engine: 'perc', params: { type:'rim', filterFreq:2200, decay:0.06, pitch:900 }
},
{
  id: 'perc-tribal-conga', name: 'Tribal Conga Loop', category: 'perc',
  keyword: 'tribal conga percussion loop',
  desc: 'A short pitched-drum pattern with a hand-drum-like pitch envelope.',
  role: 'Brings a human, tribal groove into the pattern — a signature of tribal and hypnotic techno that moves the track away from pure machine rhythm.',
  engine: 'perc', params: { type:'tom', filterFreq:1200, decay:0.14, pitch:220 }
},
{
  id: 'perc-metallic-stab', name: 'Metallic Perc Stab', category: 'perc',
  keyword: 'metallic percussion stab',
  desc: 'A short cluster of inharmonic sine partials, like a struck piece of metal.',
  role: 'A texture hit rather than a rhythm hit — scattered through a pattern to add unpredictability and a cold, industrial color.',
  engine: 'perc', params: { type:'metal', filterFreq:3000, decay:0.2, pitch:650 }
},
{
  id: 'perc-woodblock', name: 'Woodblock Click', category: 'perc',
  keyword: 'woodblock click percussion',
  desc: 'A very short, dry, high-pitched knock with almost no resonance.',
  role: 'A precise rhythmic anchor for minimal and micro-house-leaning techno, where every hit needs to be tiny and exact.',
  engine: 'perc', params: { type:'wood', filterFreq:2800, decay:0.04, pitch:1500 }
},
{
  id: 'perc-industrial-hit', name: 'Industrial Metal Hit', category: 'perc',
  keyword: 'industrial metal hit percussion, harsh',
  desc: 'A loud, dissonant metallic impact with a longer, clanging decay.',
  role: 'Used sparingly as a signature accent in industrial techno — one well-placed hit can define the whole track\u2019s character.',
  engine: 'perc', params: { type:'metal', filterFreq:2200, decay:0.45, pitch:340 }
},
{
  id: 'perc-modular-blip', name: 'Modular Percussion Blip', category: 'perc',
  keyword: 'modular synth percussion blip',
  desc: 'A tiny, pitched electronic blip with a fast pitch drop.',
  role: 'A modern, synthetic percussion accent common in minimal and modular-hardware-inspired techno, adding rhythmic detail without acoustic character.',
  engine: 'perc', params: { type:'blip', filterFreq:5000, decay:0.05, pitch:1100 }
},

// -------------------------------------------------------------- BASS / SUB
{
  id: 'bass-acid-303', name: 'Rolling Acid Bassline (303-style)', category: 'bass',
  keyword: 'rolling acid 303 bassline, resonant squelch',
  desc: 'A resonant sawtooth line with a fast filter-envelope squelch on each note.',
  role: 'The defining sound of acid techno — the resonance and filter envelope turn a simple bassline into a constantly mutating lead voice.',
  engine: 'bass', params: { waveform:'sawtooth', baseFreq:65, filterCutoff:400, filterQ:14, filterEnvAmount:2600, filterEnvDecay:0.14, drive:0.2, sub:0.1, glide:false, pattern:'rolling' }
},
{
  id: 'bass-straight-sub', name: 'Straight Sub Bass', category: 'bass',
  keyword: 'deep straight sub bass, clean',
  desc: 'A pure, filtered sine/triangle low end with no movement or distortion.',
  role: 'Pure low-end weight that sits below everything else — used when the groove needs to feel physical without adding melodic content.',
  engine: 'bass', params: { waveform:'sine', baseFreq:45, filterCutoff:250, filterQ:0.7, filterEnvAmount:0, filterEnvDecay:0.1, drive:0, sub:0.9, glide:false, pattern:'single' }
},
{
  id: 'bass-reese', name: 'Reese Bass', category: 'bass',
  keyword: 'growling detuned reese bass',
  desc: 'Two or more detuned sawtooths beating against each other for a growling texture.',
  role: 'Adds a thick, moving low end with harmonic tension — common where a track wants more aggression than a clean sub without going fully distorted.',
  engine: 'bass', params: { waveform:'sawtooth', baseFreq:55, filterCutoff:700, filterQ:2, filterEnvAmount:200, filterEnvDecay:0.3, drive:0.15, sub:0.4, glide:false, pattern:'single', detuneVoices:true }
},
{
  id: 'bass-dub-chord', name: 'Dub Techno Bass Chord', category: 'bass',
  keyword: 'dub techno bass chord stab, filtered',
  desc: 'A low, filtered chord stab rather than a single note, with a soft attack.',
  role: 'In dub techno the bass often carries harmony, not just rhythm — a chord stab here does double duty as bassline and chord progression.',
  engine: 'bass', params: { waveform:'triangle', baseFreq:60, filterCutoff:350, filterQ:1.2, filterEnvAmount:150, filterEnvDecay:0.6, drive:0, sub:0.5, glide:false, pattern:'single', chord:true }
},
{
  id: 'bass-hoover', name: 'Hoover Bass', category: 'bass',
  keyword: 'rave hoover bass, rising growl',
  desc: 'A detuned, pitch-rising saw stack that swells like the classic rave \u201choover\u201d sound.',
  role: 'A nostalgic, aggressive texture for peak moments — instantly recognizable from early-90s rave and still used in hard and hard-groove techno for impact.',
  engine: 'bass', params: { waveform:'sawtooth', baseFreq:70, filterCutoff:900, filterQ:3, filterEnvAmount:400, filterEnvDecay:0.4, drive:0.3, sub:0.2, glide:true, pattern:'single', detuneVoices:true }
},
{
  id: 'bass-fm-growl', name: 'FM Growl Bass', category: 'bass',
  keyword: 'distorted FM growl bass, aggressive',
  desc: 'A harsh, ring-modulated, heavily distorted low end with an irregular growl.',
  role: 'Hard techno\u2019s answer to a screaming lead — it fills the low-mid with aggression and pushes the whole track\u2019s intensity up a notch.',
  engine: 'bass', params: { waveform:'square', baseFreq:60, filterCutoff:1200, filterQ:4, filterEnvAmount:300, filterEnvDecay:0.2, drive:0.75, sub:0.2, glide:false, pattern:'single', ringMod:true }
},
{
  id: 'bass-minimal-rolling', name: 'Minimal Rolling Bassline', category: 'bass',
  keyword: 'minimal rolling bassline groove, tight',
  desc: 'A short, dry, repeating low note pattern with a tight filter and light swing.',
  role: 'Keeps a minimal track moving for long stretches — the groove comes from subtle timing and filter changes rather than melody.',
  engine: 'bass', params: { waveform:'sawtooth', baseFreq:58, filterCutoff:500, filterQ:2, filterEnvAmount:250, filterEnvDecay:0.1, drive:0.05, sub:0.3, glide:false, pattern:'rolling' }
},
{
  id: 'bass-hard-distorted', name: 'Hard Techno Distorted Bass', category: 'bass',
  keyword: 'hard techno distorted bassline, wall of sound',
  desc: 'A fully saturated, near-square low end pushed hard enough to lose its pitch definition.',
  role: 'Fuses with the kick into a single wall of low-end energy — a hard techno production trademark where kick and bass are barely separable.',
  engine: 'bass', params: { waveform:'square', baseFreq:50, filterCutoff:1500, filterQ:1, filterEnvAmount:0, filterEnvDecay:0.1, drive:0.9, sub:0.5, glide:false, pattern:'single' }
},

// ---------------------------------------------------------- LEAD / STAB / ARP
{
  id: 'lead-rave-stab', name: 'Rave Stab', category: 'lead', subtype:'stab',
  keyword: 'classic rave stab chord, filtered hit',
  desc: 'A fast-attack chord hit with a quick filter close, gone almost as soon as it lands.',
  role: 'A punctuation mark — used on off-beats or accents to add energy without ever becoming a sustained melodic element.',
  engine: 'lead', params: { subtype:'stab', waveform:'sawtooth', intervals:[0,7,12], baseFreq:220, detune:8, filterCutoff:3000, filterEnvAmount:2000, attack:0.003, decay:0.22 }
},
{
  id: 'lead-analog-pluck', name: 'Analog Pluck Synth', category: 'lead', subtype:'stab',
  keyword: 'analog pluck synth, warm decay',
  desc: 'A single warm note with a fast pluck-like attack and a natural, rounded decay.',
  role: 'Melodic techno\u2019s bread and butter — plucks carry the emotional melody while staying rhythmically tight enough not to clutter the groove.',
  engine: 'lead', params: { subtype:'stab', waveform:'triangle', intervals:[0], baseFreq:330, detune:4, filterCutoff:2200, filterEnvAmount:1200, attack:0.004, decay:0.35 }
},
{
  id: 'lead-detuned-saw', name: 'Detuned Saw Lead', category: 'lead', subtype:'stab',
  keyword: 'detuned saw lead, wide and thick',
  desc: 'A thick, chorused lead built from several slightly-detuned sawtooth voices.',
  role: 'Fills out the top of a mix with width and body — a go-to for melodic and driving techno hooks that need to feel big without shouting.',
  engine: 'lead', params: { subtype:'stab', waveform:'sawtooth', intervals:[0], baseFreq:294, detune:14, filterCutoff:3400, filterEnvAmount:1500, attack:0.01, decay:0.5 }
},
{
  id: 'lead-hypnotic-arp', name: 'Hypnotic Arpeggio', category: 'lead', subtype:'arp',
  keyword: 'hypnotic 16th-note arpeggio sequence',
  desc: 'A fast, repeating sequence of short notes stepping through a small set of pitches.',
  role: 'The engine behind hypnotic and minimal techno\u2019s trance-like pull — a simple pattern, repeated with tiny variations, that rewards long, close listening.',
  engine: 'lead', params: { subtype:'arp', waveform:'square', intervals:[0,3,7,10], baseFreq:440, detune:2, filterCutoff:2600, filterEnvAmount:900, attack:0.002, decay:0.09 }
},
{
  id: 'lead-acid-squelch', name: 'Acid Squelch Lead', category: 'lead', subtype:'arp',
  keyword: 'squelchy acid lead, high resonance',
  desc: 'A resonant, filter-swept lead line similar to the acid bassline but pitched higher and busier.',
  role: 'When the acid line moves from bass into lead territory it becomes the main melodic hook of the track, not just groove support.',
  engine: 'lead', params: { subtype:'arp', waveform:'sawtooth', intervals:[0,3,5,7], baseFreq:520, detune:0, filterCutoff:900, filterEnvAmount:2400, attack:0.001, decay:0.11 }
},
{
  id: 'lead-melodic-pluck-seq', name: 'Melodic Techno Pluck Sequence', category: 'lead', subtype:'arp',
  keyword: 'melodic techno pluck sequence, emotive',
  desc: 'A slower, more spacious sequence of plucked notes outlining a minor-key melody.',
  role: 'Carries the emotional arc of a melodic techno track across a long build — the space between notes matters as much as the notes themselves.',
  engine: 'lead', params: { subtype:'arp', waveform:'triangle', intervals:[0,3,7,10,12], baseFreq:262, detune:3, filterCutoff:2000, filterEnvAmount:800, attack:0.01, decay:0.3 }
},
{
  id: 'lead-filtered-stab', name: 'Filtered Stab Chord', category: 'lead', subtype:'stab',
  keyword: 'filtered stab chord hit, muted',
  desc: 'A chord hit with the filter closed down low so only its edge is audible.',
  role: 'A textural rather than melodic hit — implies harmony without drawing attention away from the groove, common in deep and minimal styles.',
  engine: 'lead', params: { subtype:'stab', waveform:'sawtooth', intervals:[0,4,7], baseFreq:196, detune:6, filterCutoff:900, filterEnvAmount:1400, attack:0.004, decay:0.28 }
},
{
  id: 'lead-fm-bell', name: 'FM Bell Lead', category: 'lead', subtype:'stab',
  keyword: 'metallic FM bell lead, glassy',
  desc: 'An inharmonic, bell-like tone with a bright, glassy attack and a slow fade.',
  role: 'Adds a cold, futuristic melodic color that cuts through dense percussion without needing much volume.',
  engine: 'lead', params: { subtype:'stab', waveform:'sine', intervals:[0,12,19], baseFreq:392, detune:0, filterCutoff:6000, filterEnvAmount:400, attack:0.002, decay:0.9, bell:true }
},

// --------------------------------------------------------- PAD / CHORD / DRONE
{
  id: 'pad-dark-analog', name: 'Dark Analog Pad', category: 'pad',
  keyword: 'dark analog pad, slow attack',
  desc: 'A slow-swelling, minor-key chord built from several detuned oscillators.',
  role: 'Sets the emotional undertone of a track — dark pads are the difference between a techno track that grooves and one that feels ominous.',
  engine: 'pad', params: { intervals:[0,3,7], baseFreq:130, voices:4, detune:10, attack:1.2, release:1.8, filterCutoff:1400, lfoRate:0.15, lfoDepth:200, waveform:'sawtooth' }
},
{
  id: 'pad-evolving-drone', name: 'Slow Evolving Drone', category: 'pad',
  keyword: 'slow evolving drone pad, atmospheric',
  desc: 'A long, single sustained tone that slowly shifts timbre via a slow filter sweep.',
  role: 'Glue for long transitions and intros — a drone gives the ear something constant to hold onto while other elements enter and leave.',
  engine: 'pad', params: { intervals:[0], baseFreq:110, voices:3, detune:6, attack:2, release:3, filterCutoff:800, lfoRate:0.08, lfoDepth:300, waveform:'sine' }
},
{
  id: 'pad-detuned-wash', name: 'Detuned Chord Wash', category: 'pad',
  keyword: 'detuned chord wash pad, wide',
  desc: 'A wide, shimmering chord with heavy detuning for a chorused, ambient wash.',
  role: 'Fills the stereo field behind a sparse arrangement, giving minimal productions a sense of depth without adding rhythmic complexity.',
  engine: 'pad', params: { intervals:[0,4,7,11], baseFreq:174, voices:5, detune:16, attack:1.5, release:2.2, filterCutoff:2200, lfoRate:0.2, lfoDepth:400, waveform:'sawtooth' }
},
{
  id: 'pad-dub-chord-reverb', name: 'Dub Chord Stab (Reverb-Drenched)', category: 'pad',
  keyword: 'reverb-drenched dub chord stab, spacious',
  desc: 'A short chord hit conceptually designed to trail into a long, spacious reverb tail.',
  role: 'The signature dub techno move — a simple chord becomes an atmosphere in its own right once it is soaked in reverb and left to decay.',
  engine: 'pad', params: { intervals:[0,3,7,10], baseFreq:220, voices:3, detune:5, attack:0.05, release:2.6, filterCutoff:1800, lfoRate:0.1, lfoDepth:150, waveform:'triangle' }
},
{
  id: 'pad-warehouse-ambience', name: 'Warehouse Ambience Drone', category: 'pad',
  keyword: 'warehouse ambience drone, low rumble',
  desc: 'A low, murky drone built to sound like distant room tone and machinery.',
  role: 'Used under intros and breakdowns to plant the listener physically \u201cin the room\u201d before the groove starts.',
  engine: 'pad', params: { intervals:[0,5], baseFreq:70, voices:3, detune:8, attack:2.5, release:3, filterCutoff:500, lfoRate:0.05, lfoDepth:120, waveform:'sawtooth' }
},
{
  id: 'pad-melodic-string', name: 'Melodic Techno String Pad', category: 'pad',
  keyword: 'melodic techno string pad, emotive',
  desc: 'A string-like sustained pad with a slower attack and a rich, layered harmonic.',
  role: 'Brings the cinematic, emotional lift that defines modern melodic techno breakdowns and peaks.',
  engine: 'pad', params: { intervals:[0,4,7,12], baseFreq:196, voices:5, detune:9, attack:1.6, release:2, filterCutoff:2600, lfoRate:0.12, lfoDepth:250, waveform:'sawtooth' }
},
{
  id: 'pad-sub-drone', name: 'Sub-Bass Drone', category: 'pad',
  keyword: 'sub bass drone, deep and static',
  desc: 'A very low, nearly static sine tone sustained for a long duration.',
  role: 'A foundation layer under a breakdown or ambient section, keeping low-end presence even when the kick drops out.',
  engine: 'pad', params: { intervals:[0], baseFreq:42, voices:1, detune:0, attack:1, release:2, filterCutoff:200, lfoRate:0.05, lfoDepth:20, waveform:'sine' }
},

// ------------------------------------------------------------- FX / RISER / IMPACT
{
  id: 'fx-white-noise-riser', name: 'White Noise Riser', category: 'fx',
  keyword: 'white noise riser, building tension',
  desc: 'A filtered noise sweep that rises in pitch and volume over several bars.',
  role: 'The most common build tool in electronic music — it tells the listener\u2019s ear that a drop or new section is coming.',
  engine: 'fx', params: { type:'riser', startFreq:200, endFreq:9000, duration:3.2, noiseMix:1 }
},
{
  id: 'fx-filter-sweep-riser', name: 'Resonant Filter Sweep Riser', category: 'fx',
  keyword: 'resonant filter sweep riser',
  desc: 'A resonant filter opening slowly on a held tone, adding a whistling edge as it climbs.',
  role: 'A more melodic alternative to a pure noise riser — useful when the build needs a pitched element rather than pure texture.',
  engine: 'fx', params: { type:'sweep', startFreq:150, endFreq:6000, duration:3.6, noiseMix:0.4 }
},
{
  id: 'fx-downlifter-impact', name: 'Cinematic Downlifter Impact', category: 'fx',
  keyword: 'cinematic downlifter impact, sub drop',
  desc: 'A sharp hit followed by a fast downward pitch and volume sweep.',
  role: 'Marks the exact moment of a drop or transition with a physical, felt impact rather than just a rhythmic change.',
  engine: 'fx', params: { type:'downlifter', startFreq:2000, endFreq:30, duration:1.4, noiseMix:0.3 }
},
{
  id: 'fx-reverse-cymbal', name: 'Reverse Cymbal Swell', category: 'fx',
  keyword: 'reverse cymbal swell, into the drop',
  desc: 'A cymbal-like wash that swells upward in volume and cuts off abruptly, as if played backwards.',
  role: 'A classic transition device — the abrupt cutoff creates a small silence that makes the next hit land harder.',
  engine: 'fx', params: { type:'reverseCymbal', startFreq:4000, endFreq:9000, duration:1.8, noiseMix:0.9 }
},
{
  id: 'fx-scifi-sweep', name: 'Sci-Fi Sweep', category: 'fx',
  keyword: 'sci-fi sweep fx, resonant',
  desc: 'A fast, highly resonant filter sweep across a wide frequency range, almost tonal.',
  role: 'Adds a futuristic, otherworldly texture used sparingly as an ear-catching transition or intro element.',
  engine: 'fx', params: { type:'sweep', startFreq:100, endFreq:8000, duration:1.6, noiseMix:0.15 }
},
{
  id: 'fx-sidechain-pump', name: 'Sidechain Pumping FX Texture', category: 'fx',
  keyword: 'sidechain pumping fx texture, breathing',
  desc: 'A sustained pad-like texture with a rhythmic volume pump synced to the beat.',
  role: 'Suno cannot sidechain a mix the way a DAW can, but naming this effect nudges the model toward that pumping, \u201cbreathing\u201d rhythmic energy in the arrangement.',
  engine: 'fx', params: { type:'pump', startFreq:300, endFreq:300, duration:2, noiseMix:0.2 }
},
{
  id: 'fx-metallic-clang', name: 'Metallic Clang Impact', category: 'fx',
  keyword: 'metallic clang impact, industrial hit',
  desc: 'A dissonant, ringing metallic hit with a long, irregular decay.',
  role: 'A signature industrial techno accent used at section changes for shock value rather than groove.',
  engine: 'fx', params: { type:'clang', startFreq:1200, endFreq:1200, duration:1.2, noiseMix:0.3 }
},
{
  id: 'fx-tension-riser', name: 'Rising Tension Build-Up FX', category: 'fx',
  keyword: 'rising tension buildup fx, snare-roll style',
  desc: 'A rapid series of short, accelerating hits that increase in density toward a peak.',
  role: 'Mimics a drum-roll build — creates urgency right before a drop even in a fully synthesized, non-acoustic arrangement.',
  engine: 'fx', params: { type:'tensionRiser', startFreq:2000, endFreq:2000, duration:2.4, noiseMix:0.6 }
},
{
  id: 'fx-reverse-kick-swell', name: 'Reverse Kick Swell', category: 'fx',
  keyword: 'reverse kick swell, into the beat',
  desc: 'A low tone that swells upward in volume and pitch, aimed at landing right on the next downbeat.',
  role: 'A subtle transition trick borrowed from dub and minimal techno to lead the ear back into the groove after a breakdown.',
  engine: 'fx', params: { type:'reverseCymbal', startFreq:40, endFreq:180, duration:1.1, noiseMix:0.05 }
},

// --------------------------------------------------------- TEXTURE / ATMOSPHERE
{
  id: 'texture-vinyl-crackle', name: 'Vinyl Crackle / Tape Hiss', category: 'texture',
  keyword: 'vinyl crackle tape hiss texture, warm',
  desc: 'A constant, low-level crackling noise texture evoking an old record or tape.',
  role: 'Adds analog warmth and imperfection under a clean digital arrangement, common in dub and deep techno.',
  engine: 'texture', params: { type:'crackle', filterFreq:5000, filterQ:0.7, lfoRate:0.3, lfoDepth:0.4, duration:4 }
},
{
  id: 'texture-industrial-noise-bed', name: 'Industrial Noise Texture Bed', category: 'texture',
  keyword: 'industrial noise texture bed, grinding',
  desc: 'A dense, grinding wall of filtered noise sustained under the main elements.',
  role: 'Fills the background with mechanical chaos, reinforcing an industrial track\u2019s factory-floor atmosphere.',
  engine: 'texture', params: { type:'noiseBed', filterFreq:1800, filterQ:2, lfoRate:0.4, lfoDepth:0.6, duration:4 }
},
{
  id: 'texture-modular-drone', name: 'Modular Machine Drone', category: 'texture',
  keyword: 'modular machine drone texture, mechanical',
  desc: 'A low, irregular, slowly modulating tone resembling idle hardware or a modular patch.',
  role: 'Adds unpredictable, organic movement to an otherwise rigid grid-based arrangement.',
  engine: 'texture', params: { type:'drone', baseFreq:65, filterFreq:900, filterQ:1.5, lfoRate:0.6, lfoDepth:0.5, duration:4.5 }
},
{
  id: 'texture-warehouse-hum', name: 'Warehouse Machine Hum Ambience', category: 'texture',
  keyword: 'warehouse machine hum ambience',
  desc: 'A steady, low hum meant to suggest distant ventilation or machinery.',
  role: 'A near-subliminal layer that gives an intro or breakdown a physical sense of place.',
  engine: 'texture', params: { type:'hum', baseFreq:110, filterFreq:600, filterQ:3, lfoRate:0.1, lfoDepth:0.15, duration:5 }
},
{
  id: 'texture-granular-static', name: 'Granular Static Texture', category: 'texture',
  keyword: 'granular static texture, glitchy',
  desc: 'A stuttering, grainy noise texture built from rapid tiny bursts.',
  role: 'Adds a modern, glitchy detail layer favored in more experimental and broken-techno productions.',
  engine: 'texture', params: { type:'granular', filterFreq:4000, filterQ:1, lfoRate:8, lfoDepth:0.8, duration:3.5 }
},
{
  id: 'texture-sub-rumble', name: 'Distant Sub Rumble Texture', category: 'texture',
  keyword: 'distant sub rumble texture, ominous',
  desc: 'A very low, slowly fluctuating rumble with almost no defined pitch.',
  role: 'Builds unease under a breakdown or intro without a defined bassline, common in darker techno subgenres.',
  engine: 'texture', params: { type:'rumble', baseFreq:35, filterFreq:150, filterQ:1, lfoRate:0.15, lfoDepth:0.3, duration:5 }
},
{
  id: 'texture-broken-radio', name: 'Broken Radio Static FX', category: 'texture',
  keyword: 'broken radio static texture, lo-fi',
  desc: 'A narrow-band, crackling noise texture like a badly tuned radio signal.',
  role: 'A quick ear-catching texture for transitions or intros that need a lo-fi, found-sound feel.',
  engine: 'texture', params: { type:'staticRadio', filterFreq:2200, filterQ:6, lfoRate:1.2, lfoDepth:0.7, duration:3 }
},

];
