/* ==========================================================================
   AUDIO ENGINE
   Pure Web Audio API synthesis (zero external audio files, zero dependencies)
   that renders short, original approximations of each sound in the library,
   plus a lookahead-scheduled 16-step groove transport so sounds can be heard
   layered against a beat. These are synthesis sketches for reference, not
   reproductions of any copyrighted sample, patch, or recording.
   ========================================================================== */

class TechnoAudioEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.noiseBuffer = null;
    this.pinkNoiseBuffer = null;
    this.lookahead = 25.0;          // ms, scheduler tick
    this.scheduleAheadTime = 0.12;  // seconds, how far ahead we schedule audio
    this.grooveState = { playing: false, bpm: 128, step: 0, nextStepTime: 0, barCount: 0, layers: {} };
    this._grooveInterval = null;
    this.onStep = null; // UI hook: (step:number) => void
  }

  // ---------------------------------------------------------------- SETUP
  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.85;
    const comp = this.ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.knee.value = 24;
    comp.ratio.value = 5;
    comp.attack.value = 0.003;
    comp.release.value = 0.22;
    this.master.connect(comp);
    comp.connect(this.ctx.destination);
    this._buildNoiseBuffers();
  }

  resume() {
    this.init();
    if (this.ctx.state === 'suspended') this.ctx.resume();
  }

  _buildNoiseBuffers() {
    const len = this.ctx.sampleRate * 2;
    const whiteBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const wd = whiteBuf.getChannelData(0);
    for (let i = 0; i < len; i++) wd[i] = Math.random() * 2 - 1;
    this.noiseBuffer = whiteBuf;

    const pinkBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const pd = pinkBuf.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      pd[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
      b6 = white * 0.115926;
    }
    this.pinkNoiseBuffer = pinkBuf;
  }

  _noiseSource(color) {
    const src = this.ctx.createBufferSource();
    src.buffer = color === 'pink' ? this.pinkNoiseBuffer : this.noiseBuffer;
    src.loop = true;
    src.loopEnd = src.buffer.duration;
    return src;
  }

  _makeDistortion(amount) {
    const ws = this.ctx.createWaveShaper();
    const k = Math.max(amount, 0.001) * 100;
    const n = 44100;
    const curve = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const x = (i * 2) / n - 1;
      curve[i] = ((1 + k) * x) / (1 + k * Math.abs(x));
    }
    ws.curve = curve;
    ws.oversample = '4x';
    return ws;
  }

  // ----------------------------------------------------------------- KICK
  kick(time, p, destination) {
    const ctx = this.ctx, out = destination || this.master;
    const startFreq = p.startFreq || 160, endFreq = p.endFreq || 48;
    const ampDecay = p.ampDecay || 0.3;

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(startFreq, time);
    osc.frequency.exponentialRampToValueAtTime(Math.max(endFreq, 20), time + (p.pitchDecay || 0.05));

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, time);
    gain.gain.exponentialRampToValueAtTime(1, time + 0.002);
    gain.gain.exponentialRampToValueAtTime(0.001, time + ampDecay);

    if (p.drive) {
      const dist = this._makeDistortion(p.drive);
      osc.connect(dist); dist.connect(gain);
    } else {
      osc.connect(gain);
    }

    if (p.tone) {
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = p.tone;
      gain.connect(lp); lp.connect(out);
    } else {
      gain.connect(out);
    }

    osc.start(time); osc.stop(time + ampDecay + 0.05);

    if (p.click) {
      const clickGain = ctx.createGain();
      clickGain.gain.setValueAtTime(p.click * 0.7, time);
      clickGain.gain.exponentialRampToValueAtTime(0.001, time + 0.015);
      const src = this._noiseSource('white');
      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = 2000;
      src.connect(hp); hp.connect(clickGain); clickGain.connect(out);
      src.start(time); src.stop(time + 0.02);
    }

    if (p.sub) {
      const subOsc = ctx.createOscillator();
      subOsc.type = 'sine'; subOsc.frequency.setValueAtTime(endFreq, time);
      const subGain = ctx.createGain();
      subGain.gain.setValueAtTime(0.0001, time);
      subGain.gain.exponentialRampToValueAtTime(p.sub, time + 0.01);
      subGain.gain.exponentialRampToValueAtTime(0.001, time + ampDecay * 1.4);
      subOsc.connect(subGain); subGain.connect(out);
      subOsc.start(time); subOsc.stop(time + ampDecay * 1.4 + 0.05);
    }
    return ampDecay + 0.1;
  }

  // ------------------------------------------------------------ HAT/CYMBAL
  hat(time, p, destination) {
    const ctx = this.ctx, out = destination || this.master;
    const decay = p.decay || 0.08;
    const src = this._noiseSource(p.noiseType || 'white');
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass'; hp.frequency.value = (p.filterFreq || 8000) * 0.55;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass'; bp.frequency.value = p.filterFreq || 8000; bp.Q.value = p.filterQ || 1;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, time);
    g.gain.exponentialRampToValueAtTime(0.75, time + 0.003);
    g.gain.exponentialRampToValueAtTime(0.001, time + decay);
    src.connect(hp); hp.connect(bp); bp.connect(g); g.connect(out);
    src.start(time); src.stop(time + decay + 0.05);

    if (p.metallic) {
      const ratios = [1, 1.41, 2.3, 3.7, 5.1];
      const base = (p.filterFreq || 8000) / 3;
      ratios.forEach((r, i) => {
        const o = ctx.createOscillator();
        o.type = 'sine'; o.frequency.value = base * r;
        const og = ctx.createGain();
        og.gain.setValueAtTime(0.14 / (i + 1), time);
        og.gain.exponentialRampToValueAtTime(0.001, time + decay * 0.85);
        o.connect(og); og.connect(out);
        o.start(time); o.stop(time + decay * 0.85 + 0.05);
      });
    }
    return decay + 0.1;
  }

  // ----------------------------------------------------------- PERCUSSION
  perc(time, p, destination) {
    const ctx = this.ctx, out = destination || this.master;
    const decay = p.decay || 0.15;
    switch (p.type) {
      case 'clap': {
        const count = Math.min(p.bursts || 4, 4);
        for (let i = 0; i < count; i++) {
          const t = time + i * 0.011;
          const src = this._noiseSource('white');
          const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = p.filterFreq || 1500; bp.Q.value = 3;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0.0001, t);
          g.gain.exponentialRampToValueAtTime(0.55, t + 0.003);
          g.gain.exponentialRampToValueAtTime(0.001, t + 0.035);
          src.connect(bp); bp.connect(g); g.connect(out);
          src.start(t); src.stop(t + 0.045);
        }
        const tailT = time + count * 0.011 + 0.02;
        const tailSrc = this._noiseSource('white');
        const bp2 = ctx.createBiquadFilter(); bp2.type = 'bandpass'; bp2.frequency.value = (p.filterFreq || 1500) * 0.9; bp2.Q.value = 1.4;
        const g2 = ctx.createGain();
        g2.gain.setValueAtTime(0.0001, tailT);
        g2.gain.exponentialRampToValueAtTime(0.4, tailT + 0.005);
        g2.gain.exponentialRampToValueAtTime(0.001, tailT + decay);
        tailSrc.connect(bp2); bp2.connect(g2); g2.connect(out);
        tailSrc.start(tailT); tailSrc.stop(tailT + decay + 0.05);
        return decay + 0.2;
      }
      case 'rim': {
        const src = this._noiseSource('white');
        const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = p.filterFreq || 2200; bp.Q.value = 4;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.5, time);
        g.gain.exponentialRampToValueAtTime(0.001, time + decay);
        src.connect(bp); bp.connect(g); g.connect(out);
        src.start(time); src.stop(time + decay + 0.03);

        const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = p.pitch || 900;
        const og = ctx.createGain();
        og.gain.setValueAtTime(0.3, time);
        og.gain.exponentialRampToValueAtTime(0.001, time + decay * 0.7);
        o.connect(og); og.connect(out);
        o.start(time); o.stop(time + decay + 0.02);
        return decay + 0.1;
      }
      case 'tom': {
        const o = ctx.createOscillator(); o.type = 'triangle';
        const startF = (p.pitch || 220) * 1.6;
        o.frequency.setValueAtTime(startF, time);
        o.frequency.exponentialRampToValueAtTime(p.pitch || 220, time + 0.05);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.7, time);
        g.gain.exponentialRampToValueAtTime(0.001, time + decay);
        o.connect(g); g.connect(out);
        o.start(time); o.stop(time + decay + 0.05);
        return decay + 0.1;
      }
      case 'metal': {
        const ratios = [1, 1.6, 2.45, 3.9, 5.2];
        const base = p.pitch || 500;
        ratios.forEach((r, i) => {
          const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = base * r;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0.22 / (i * 0.7 + 1), time);
          g.gain.exponentialRampToValueAtTime(0.001, time + decay * (1 - i * 0.1));
          o.connect(g); g.connect(out);
          o.start(time); o.stop(time + decay + 0.1);
        });
        const src = this._noiseSource('white');
        const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = p.filterFreq || 3000;
        const ng = ctx.createGain();
        ng.gain.setValueAtTime(0.28, time);
        ng.gain.exponentialRampToValueAtTime(0.001, time + 0.02);
        src.connect(hp); hp.connect(ng); ng.connect(out);
        src.start(time); src.stop(time + 0.03);
        return decay + 0.15;
      }
      case 'wood': {
        const src = this._noiseSource('white');
        const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = p.filterFreq || 2800; bp.Q.value = 8;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.6, time);
        g.gain.exponentialRampToValueAtTime(0.001, time + decay);
        src.connect(bp); bp.connect(g); g.connect(out);
        src.start(time); src.stop(time + decay + 0.02);

        const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = p.pitch || 1500;
        const og = ctx.createGain();
        og.gain.setValueAtTime(0.2, time);
        og.gain.exponentialRampToValueAtTime(0.001, time + decay * 0.6);
        o.connect(og); og.connect(out);
        o.start(time); o.stop(time + decay + 0.02);
        return decay + 0.1;
      }
      case 'blip': {
        const o = ctx.createOscillator(); o.type = 'square';
        o.frequency.setValueAtTime((p.pitch || 1100) * 1.5, time);
        o.frequency.exponentialRampToValueAtTime(p.pitch || 1100, time + 0.02);
        const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = p.filterFreq || 5000;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.4, time);
        g.gain.exponentialRampToValueAtTime(0.001, time + decay);
        o.connect(f); f.connect(g); g.connect(out);
        o.start(time); o.stop(time + decay + 0.02);
        return decay + 0.1;
      }
      default: return 0.1;
    }
  }

  // ------------------------------------------------------------ BASS/SUB
  bass(time, p, destination) {
    const ctx = this.ctx, out = destination || this.master;

    const playNote = (t, freq, dur) => {
      const voices = [];
      const o1 = ctx.createOscillator(); o1.type = p.waveform || 'sawtooth'; o1.frequency.setValueAtTime(freq, t);
      if (p.glide) { o1.frequency.setValueAtTime(freq * 0.85, t); o1.frequency.exponentialRampToValueAtTime(freq, t + 0.08); }
      voices.push(o1);
      if (p.detuneVoices) {
        const o2 = ctx.createOscillator(); o2.type = p.waveform || 'sawtooth'; o2.frequency.value = freq; o2.detune.value = 12;
        const o3 = ctx.createOscillator(); o3.type = p.waveform || 'sawtooth'; o3.frequency.value = freq; o3.detune.value = -12;
        voices.push(o2, o3);
      }

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass'; filter.Q.value = p.filterQ || 4;
      const baseCutoff = p.filterCutoff || 500;
      filter.frequency.setValueAtTime(baseCutoff + (p.filterEnvAmount || 0), t);
      filter.frequency.exponentialRampToValueAtTime(Math.max(baseCutoff, 60), t + (p.filterEnvDecay || 0.15));

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.75, t + 0.005);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);

      voices.forEach(v => v.connect(filter));

      if (p.ringMod) {
        const ringOsc = ctx.createOscillator(); ringOsc.type = 'sine'; ringOsc.frequency.value = freq * 2.3;
        const ringGain = ctx.createGain(); ringGain.gain.value = 0.35;
        ringOsc.connect(ringGain); ringGain.connect(filter);
        ringOsc.start(t); ringOsc.stop(t + dur + 0.1);
      }

      if (p.drive) {
        const dist = this._makeDistortion(p.drive);
        filter.connect(dist); dist.connect(g);
      } else {
        filter.connect(g);
      }
      g.connect(out);
      voices.forEach(v => { v.start(t); v.stop(t + dur + 0.05); });

      if (p.sub) {
        const subOsc = ctx.createOscillator(); subOsc.type = 'sine'; subOsc.frequency.value = freq / 2;
        const subGain = ctx.createGain();
        subGain.gain.setValueAtTime(0.0001, t);
        subGain.gain.exponentialRampToValueAtTime(p.sub, t + 0.01);
        subGain.gain.exponentialRampToValueAtTime(0.001, t + dur);
        subOsc.connect(subGain); subGain.connect(out);
        subOsc.start(t); subOsc.stop(t + dur + 0.05);
      }
      if (p.chord) {
        [7, 10].forEach(semi => {
          const co = ctx.createOscillator(); co.type = p.waveform || 'triangle';
          co.frequency.value = freq * Math.pow(2, semi / 12);
          const cg = ctx.createGain();
          cg.gain.setValueAtTime(0.0001, t);
          cg.gain.exponentialRampToValueAtTime(0.28, t + 0.01);
          cg.gain.exponentialRampToValueAtTime(0.001, t + dur);
          co.connect(cg); cg.connect(out);
          co.start(t); co.stop(t + dur + 0.05);
        });
      }
    };

    const base = p.baseFreq || 55;
    if (p.pattern === 'rolling') {
      const steps = [0, 0, 3, 0, 0, 2, 0, 5];
      const stepDur = 0.16;
      steps.forEach((semi, i) => playNote(time + i * stepDur, base * Math.pow(2, semi / 12), stepDur * 0.85));
      return steps.length * stepDur + 0.2;
    } else {
      const dur = p.chord ? 0.9 : 0.6;
      playNote(time, base, dur);
      return dur + 0.2;
    }
  }

  // -------------------------------------------------------- LEAD/STAB/ARP
  lead(time, p, destination) {
    const ctx = this.ctx, out = destination || this.master;

    const playVoice = (t, freq, dur, intervals) => {
      const ivs = intervals && intervals.length ? intervals : [0];
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass'; filter.Q.value = 2;
      const baseCutoff = p.filterCutoff || 2000;
      filter.frequency.setValueAtTime(baseCutoff + (p.filterEnvAmount || 0), t);
      filter.frequency.exponentialRampToValueAtTime(Math.max(baseCutoff * 0.55, 200), t + dur);

      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.5 / ivs.length + 0.08, t + (p.attack || 0.005));
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);

      ivs.forEach(semi => {
        const o = ctx.createOscillator();
        o.type = p.bell ? 'sine' : (p.waveform || 'sawtooth');
        const f = freq * Math.pow(2, semi / 12);
        o.frequency.value = f;
        if (p.detune) o.detune.value = (Math.random() * 2 - 1) * p.detune;
        o.connect(filter);
        o.start(t); o.stop(t + dur + 0.1);
        if (p.bell) {
          const o2 = ctx.createOscillator(); o2.type = 'sine'; o2.frequency.value = f * 2.756;
          const g2 = ctx.createGain(); g2.gain.value = 0.15;
          o2.connect(g2); g2.connect(filter);
          o2.start(t); o2.stop(t + dur * 0.6 + 0.1);
        }
      });
      filter.connect(g); g.connect(out);
    };

    const base = p.baseFreq || 330;
    if (p.subtype === 'arp') {
      const pattern = p.intervals && p.intervals.length ? p.intervals : [0, 3, 7, 10];
      const seq = [0, 1, 2, 3, 2, 1, 3, 0].map(i => pattern[i % pattern.length]);
      const stepDur = 0.115;
      seq.forEach((semi, i) => playVoice(time + i * stepDur, base, stepDur * 1.4, [semi]));
      return seq.length * stepDur + 0.3;
    } else {
      const dur = p.decay || 0.3;
      playVoice(time, base, dur, p.intervals);
      return dur + 0.3;
    }
  }

  // ---------------------------------------------------------- PAD/DRONE
  pad(time, p, destination, previewDur) {
    const ctx = this.ctx, out = destination || this.master;
    const dur = previewDur || 3.2;
    const intervals = p.intervals && p.intervals.length ? p.intervals : [0];
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass'; filter.frequency.value = p.filterCutoff || 1500; filter.Q.value = 1;

    if (p.lfoRate) {
      const lfo = ctx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = p.lfoRate;
      const lfoGain = ctx.createGain(); lfoGain.gain.value = p.lfoDepth || 100;
      lfo.connect(lfoGain); lfoGain.connect(filter.frequency);
      lfo.start(time); lfo.stop(time + dur + 1);
    }

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, time);
    g.gain.linearRampToValueAtTime(0.32, time + (p.attack || 1));
    g.gain.setValueAtTime(0.32, time + Math.max(dur - (p.release || 1.5), (p.attack || 1)));
    g.gain.exponentialRampToValueAtTime(0.0005, time + dur);
    filter.connect(g); g.connect(out);

    const voiceCount = p.voices || 3;
    intervals.forEach(semi => {
      for (let v = 0; v < voiceCount; v++) {
        const o = ctx.createOscillator();
        o.type = p.waveform || 'sawtooth';
        o.frequency.value = (p.baseFreq || 150) * Math.pow(2, semi / 12);
        o.detune.value = (v - (voiceCount - 1) / 2) * (p.detune || 8);
        o.connect(filter);
        o.start(time); o.stop(time + dur + 0.2);
      }
    });
    return dur + 0.3;
  }

  // ------------------------------------------------------------ FX/RISER
  fx(time, p, destination) {
    const ctx = this.ctx, out = destination || this.master;
    const dur = p.duration || 2.5;
    const noiseMix = p.noiseMix === undefined ? 1 : p.noiseMix;
    switch (p.type) {
      case 'riser': case 'sweep': {
        const src = this._noiseSource('white');
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass'; filter.Q.value = p.type === 'sweep' ? 6 : 1.2;
        filter.frequency.setValueAtTime(p.startFreq || 200, time);
        filter.frequency.exponentialRampToValueAtTime(p.endFreq || 8000, time + dur);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, time);
        g.gain.exponentialRampToValueAtTime(0.45, time + dur * 0.9);
        g.gain.linearRampToValueAtTime(0.0001, time + dur);
        src.connect(filter); filter.connect(g); g.connect(out);
        src.start(time); src.stop(time + dur + 0.1);

        if (noiseMix < 1) {
          const o = ctx.createOscillator(); o.type = 'sawtooth';
          o.frequency.setValueAtTime(p.startFreq || 200, time);
          o.frequency.exponentialRampToValueAtTime(p.endFreq || 8000, time + dur);
          const og = ctx.createGain();
          og.gain.setValueAtTime(0.0001, time);
          og.gain.exponentialRampToValueAtTime(0.3 * (1 - noiseMix), time + dur * 0.9);
          og.gain.linearRampToValueAtTime(0.0001, time + dur);
          o.connect(og); og.connect(out);
          o.start(time); o.stop(time + dur + 0.1);
        }
        return dur + 0.2;
      }
      case 'downlifter': {
        const o = ctx.createOscillator(); o.type = 'sine';
        o.frequency.setValueAtTime(p.startFreq || 2000, time);
        o.frequency.exponentialRampToValueAtTime(Math.max(p.endFreq, 20) || 30, time + dur);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.65, time);
        g.gain.exponentialRampToValueAtTime(0.001, time + dur);
        o.connect(g); g.connect(out);
        o.start(time); o.stop(time + dur + 0.1);

        const src = this._noiseSource('white');
        const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 1500;
        const ng = ctx.createGain();
        ng.gain.setValueAtTime(noiseMix, time);
        ng.gain.exponentialRampToValueAtTime(0.001, time + 0.1);
        src.connect(hp); hp.connect(ng); ng.connect(out);
        src.start(time); src.stop(time + 0.15);
        return dur + 0.2;
      }
      case 'reverseCymbal': {
        const src = this._noiseSource('white');
        const bp = ctx.createBiquadFilter(); bp.type = 'bandpass';
        bp.frequency.setValueAtTime(p.startFreq || 4000, time);
        bp.frequency.linearRampToValueAtTime(p.endFreq || 9000, time + dur);
        bp.Q.value = 1;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.0001, time);
        g.gain.exponentialRampToValueAtTime(0.55, time + dur * 0.95);
        g.gain.setValueAtTime(0.0001, time + dur);
        src.connect(bp); bp.connect(g); g.connect(out);
        src.start(time); src.stop(time + dur + 0.05);
        return dur + 0.15;
      }
      case 'pump': {
        const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = p.startFreq || 300;
        const filter = ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 1200;
        const g = ctx.createGain();
        const pumps = 4, pumpDur = dur / pumps;
        g.gain.setValueAtTime(0.0001, time);
        for (let i = 0; i < pumps; i++) {
          const t0 = time + i * pumpDur;
          g.gain.setValueAtTime(0.0001, t0);
          g.gain.linearRampToValueAtTime(0.32, t0 + pumpDur * 0.15);
          g.gain.exponentialRampToValueAtTime(0.04, t0 + pumpDur * 0.9);
        }
        o.connect(filter); filter.connect(g); g.connect(out);
        o.start(time); o.stop(time + dur + 0.1);
        return dur + 0.2;
      }
      case 'clang': {
        const ratios = [1, 1.83, 2.4, 3.76, 5.4, 6.8];
        const base = (p.startFreq || 1200) / 6;
        ratios.forEach((r, i) => {
          const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = base * r;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0.28 / (i * 0.6 + 1), time);
          g.gain.exponentialRampToValueAtTime(0.001, time + dur * (1 - i * 0.1));
          o.connect(g); g.connect(out);
          o.start(time); o.stop(time + dur + 0.1);
        });
        return dur + 0.2;
      }
      case 'tensionRiser': {
        const hits = 14;
        for (let i = 0; i < hits; i++) {
          const frac = i / hits;
          const t = time + dur * frac * frac;
          const src = this._noiseSource('white');
          const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = p.startFreq || 2000; bp.Q.value = 2;
          const g = ctx.createGain();
          g.gain.setValueAtTime(0.28 + 0.3 * frac, t);
          g.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
          src.connect(bp); bp.connect(g); g.connect(out);
          src.start(t); src.stop(t + 0.07);
        }
        return dur + 0.15;
      }
      default: return dur;
    }
  }

  // ------------------------------------------------------- TEXTURE/AMBIENCE
  texture(time, p, destination) {
    const ctx = this.ctx, out = destination || this.master;
    const dur = p.duration || 4;
    const isLow = (p.type === 'hum' || p.type === 'rumble' || p.type === 'drone');
    const src = this._noiseSource(isLow ? 'pink' : 'white');
    const filter = ctx.createBiquadFilter();
    filter.type = isLow ? 'lowpass' : 'bandpass';
    filter.frequency.value = p.filterFreq || 1500;
    filter.Q.value = p.filterQ || 1;

    if (p.lfoRate) {
      const lfo = ctx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = p.lfoRate;
      const lfoGain = ctx.createGain(); lfoGain.gain.value = (p.filterFreq || 1500) * (p.lfoDepth || 0.3);
      lfo.connect(lfoGain); lfoGain.connect(filter.frequency);
      lfo.start(time); lfo.stop(time + dur + 0.5);
    }

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, time);
    g.gain.linearRampToValueAtTime(0.38, time + 0.5);
    g.gain.setValueAtTime(0.38, time + Math.max(dur - 0.6, 0.5));
    g.gain.exponentialRampToValueAtTime(0.0005, time + dur);
    src.connect(filter); filter.connect(g); g.connect(out);
    src.start(time); src.stop(time + dur + 0.1);

    if (p.baseFreq) {
      const o = ctx.createOscillator(); o.type = 'sine'; o.frequency.value = p.baseFreq;
      const og = ctx.createGain();
      og.gain.setValueAtTime(0.0001, time);
      og.gain.linearRampToValueAtTime(0.28, time + 0.6);
      og.gain.setValueAtTime(0.28, time + Math.max(dur - 0.6, 0.6));
      og.gain.exponentialRampToValueAtTime(0.0005, time + dur);
      o.connect(og); og.connect(out);
      o.start(time); o.stop(time + dur + 0.1);
    }

    if (p.type === 'granular') {
      const rate = p.lfoRate || 8;
      const grains = Math.floor(dur * rate);
      for (let i = 0; i < grains; i++) {
        const t = time + i / rate;
        const gsrc = this._noiseSource('white');
        const gf = ctx.createBiquadFilter(); gf.type = 'bandpass'; gf.frequency.value = p.filterFreq || 4000;
        const gg = ctx.createGain();
        gg.gain.setValueAtTime(0.3, t);
        gg.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
        gsrc.connect(gf); gf.connect(gg); gg.connect(out);
        gsrc.start(t); gsrc.stop(t + 0.05);
      }
    }
    return dur + 0.2;
  }

  // ------------------------------------------------------------- DISPATCH
  preview(sound, destination, atTime) {
    this.resume();
    const time = atTime !== undefined ? atTime : this.ctx.currentTime + 0.03;
    const p = sound.params || {};
    switch (sound.engine) {
      case 'kick': return this.kick(time, p, destination);
      case 'hat': return this.hat(time, p, destination);
      case 'perc': return this.perc(time, p, destination);
      case 'bass': return this.bass(time, p, destination);
      case 'lead': return this.lead(time, p, destination);
      case 'pad': return this.pad(time, p, destination);
      case 'fx': return this.fx(time, p, destination);
      case 'texture': return this.texture(time, p, destination);
      default: return 0;
    }
  }

  // ==================================================== GROOVE TRANSPORT
  _stepDuration() { return 60 / this.grooveState.bpm / 4; }

  startGroove(bpm) {
    this.resume();
    this.grooveState.bpm = bpm || this.grooveState.bpm;
    this.grooveState.playing = true;
    this.grooveState.step = 0;
    this.grooveState.barCount = 0;
    this.grooveState.nextStepTime = this.ctx.currentTime + 0.05;
    if (this._grooveInterval) clearInterval(this._grooveInterval);
    this._grooveInterval = setInterval(() => this._grooveTick(), this.lookahead);
  }

  stopGroove() {
    this.grooveState.playing = false;
    if (this._grooveInterval) clearInterval(this._grooveInterval);
    this._grooveInterval = null;
  }

  setBpm(bpm) { this.grooveState.bpm = bpm; }

  setGrooveLayer(category, sound) { this.grooveState.layers[category] = sound; }
  clearGrooveLayer(category) { delete this.grooveState.layers[category]; }
  getGrooveLayer(category) { return this.grooveState.layers[category]; }

  _grooveTick() {
    while (this.grooveState.nextStepTime < this.ctx.currentTime + this.scheduleAheadTime) {
      this._scheduleStep(this.grooveState.step, this.grooveState.nextStepTime);
      this.grooveState.nextStepTime += this._stepDuration();
      this.grooveState.step = (this.grooveState.step + 1) % 16;
      if (this.grooveState.step === 0) this.grooveState.barCount++;
    }
  }

  _scheduleStep(step, time) {
    if (this.onStep) {
      const delayMs = Math.max(0, (time - this.ctx.currentTime) * 1000);
      setTimeout(() => this.onStep(step), delayMs);
    }
    const layers = this.grooveState.layers;
    const bar = this.grooveState.barCount;
    const kickSteps = [0, 4, 8, 12];
    const hatSteps = [2, 6, 10, 14];
    const clapSteps = [4, 12];

    if (kickSteps.includes(step)) {
      const s = layers.kick;
      if (s) this.preview(s, this.master, time);
      else this.kick(time, { startFreq: 150, endFreq: 48, pitchDecay: 0.05, ampDecay: 0.26, drive: 0.15, click: 0.4, sub: 0.4 }, this.master);
    }
    if (hatSteps.includes(step)) {
      const s = layers.hat;
      if (s) this.preview(s, this.master, time);
      else this.hat(time, { decay: 0.09, filterFreq: 8000, filterQ: 1, metallic: false, noiseType: 'white' }, this.master);
    }
    if (clapSteps.includes(step) && layers.perc) this.preview(layers.perc, this.master, time);

    if (step === 0) {
      if (layers.bass) this.preview(layers.bass, this.master, time);
      if (layers.pad) this.preview(layers.pad, this.master, time);
      if (layers.fx && bar % 4 === 0) this.preview(layers.fx, this.master, time);
      if (layers.texture && bar % 2 === 0) this.preview(layers.texture, this.master, time);
      if (layers.lead) this.preview(layers.lead, this.master, time);
    }
    if (step === 8) {
      const b = layers.bass;
      if (b && (!b.params || b.params.pattern !== 'rolling')) this.preview(b, this.master, time);
      if (layers.lead && layers.lead.subtype !== 'arp') this.preview(layers.lead, this.master, time);
    }
  }
}

window.audioEngine = new TechnoAudioEngine();
